package oracle.java.s20180102.dao;

import java.util.List;

import oracle.java.s20180102.model.MemberDto;

public interface MemberDao {

	MemberDto selMember(String id);              // 한 회원 선택
	//int upMember(MemberDto memberDto);        // 프로필 수정, 포인트 증가
	//int inMember(MemberDto memberDto);        // 회원가입
	//List<MemberDto> selMemberList();          // 회원조회
	//int delMember(String id);                 // 회원삭제
}