package oracle.java.s20180102.model;

public class ContentsDto {
	private int gServNo;
	private String gServIntro;
	private String gServOrder;
	private String imgSrc;
	
	public int getgServNo() {
		return gServNo;
	}
	public void setgServNo(int gServNo) {
		this.gServNo = gServNo;
	}
	public String getgServIntro() {
		return gServIntro;
	}
	public void setgServIntro(String gServIntro) {
		this.gServIntro = gServIntro;
	}
	public String getgServOrder() {
		return gServOrder;
	}
	public void setgServOrder(String gServOrder) {
		this.gServOrder = gServOrder;
	}
	public String getImgSrc() {
		return imgSrc;
	}
	public void setImgSrc(String imgSrc) {
		this.imgSrc = imgSrc;
	}
	
	
}
