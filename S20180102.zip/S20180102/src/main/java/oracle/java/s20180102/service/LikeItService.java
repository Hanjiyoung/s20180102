package oracle.java.s20180102.service;

import org.springframework.stereotype.Service;

@Service
public interface LikeItService {
	

	
}