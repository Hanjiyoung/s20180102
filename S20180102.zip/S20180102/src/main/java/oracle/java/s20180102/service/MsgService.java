package oracle.java.s20180102.service;

import org.springframework.stereotype.Service;

import oracle.java.s20180102.model.MsgDto;
@Service
public interface MsgService {
	//int inMsg(MsgDto msgDto);   // 보내기
	//int upMsg(MsgDto msgDto);   // 답변할 때, 받는 사람 답변여부 y로 update
	//int delMsg(MsgDto msgDto);  // 문의사항 삭제
	
}