package oracle.java.s20180102.dao;

import oracle.java.s20180102.model.MsgDto;

public interface MsgDao {
	//int inMsg(MsgDto msgDto);   // 보내기
	//int upMsg(MsgDto msgDto);   // 답변할 때, 받는 사람 답변여부 y로 update
	//int delMsg(MsgDto msgDto);  // 문의사항 삭제
	
}