package oracle.java.s20180102.service;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface SearchService {
	//int inSearch(String KeyWord);  // 검색어 누적
	//List<SearchDao> hotKeyWord();  // 인기검색어 리스트
}