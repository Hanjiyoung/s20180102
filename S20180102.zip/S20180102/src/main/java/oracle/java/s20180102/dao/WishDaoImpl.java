package oracle.java.s20180102.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;  // 
import org.springframework.stereotype.Repository;

import oracle.java.s20180102.model.GServDto;
import oracle.java.s20180102.model.PagingDto;
import oracle.java.s20180102.model.TourCardDto;

@Repository
public class WishDaoImpl implements WishDao{
	@Autowired
	private SqlSession session;

	@Override
	public List<TourCardDto> selWishList(PagingDto pdto) {
		List<GServDto> gServList = session.selectList("selWishGserv",pdto);
		List<TourCardDto> tcDto = new ArrayList<TourCardDto>();
		for(int i=0; i<gServList.size(); i++) {			
			tcDto.add(new TourCardDto());
		}		
		for(int i=0; i <gServList.size(); i++) {
			tcDto.get(i).setgNo(gServList.get(i).getgNo());
			tcDto.get(i).setgServNo(gServList.get(i).getgServNo());
			tcDto.get(i).setgServTitle(gServList.get(i).getgServTitle());
			tcDto.get(i).setgServSub(gServList.get(i).getgServSub());
			tcDto.get(i).setgServLeadTime(gServList.get(i).getgServLeadTime());
		}
		return tcDto;
	}

	@Override
	public int totalWish(String iD) {
		return session.selectOne("totalWish", iD);
	}
	
}