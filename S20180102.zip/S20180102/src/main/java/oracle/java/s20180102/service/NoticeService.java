package oracle.java.s20180102.service;

import java.util.List;

import org.springframework.stereotype.Service;

import oracle.java.s20180102.model.NoticeDto;
@Service
public interface NoticeService {
	//List<NoticeDto> selNoticeList();    // 공지사항 조회
	//int inNotice(NoticeDto noticeDto);  // 공지사항 등록
	//int upNotice(NoticeDto noticeDto);  // 공지사항 수정
	//int delNotice(int noticeNo);        // 공지사항 삭제
	
}