package oracle.java.s20180102.dao;

import java.util.List;

import oracle.java.s20180102.model.NoticeDto;

public interface NoticeDao {
	//List<NoticeDto> selNoticeList();    // 공지사항 조회
	//int inNotice(NoticeDto noticeDto);  // 공지사항 등록
	//int upNotice(NoticeDto noticeDto);  // 공지사항 수정
	//int delNotice(int noticeNo);        // 공지사항 삭제
	
}