package oracle.java.s20180102.dao;

import java.util.List;

import oracle.java.s20180102.model.QADto;

public interface QADao {
	//List<QADto> QAList(String ID, String gServNo); // 받은 문의. 보낸 문의 조회 
	//List<QADto> QAList(String complete);           // 답변여부 필터링..(?)
	//int inQA(QADto qaDto);                         // 문의 등록
	//int upQA(QADto qaDto);                         // 문의 수정
	//int delQA(int QAnumber);                       // 문의 삭제
}