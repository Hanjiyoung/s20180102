package oracle.java.s20180102.dao;

public interface LikeItDao {
	

	
}