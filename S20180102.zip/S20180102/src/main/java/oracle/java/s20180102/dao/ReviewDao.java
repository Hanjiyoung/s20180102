package oracle.java.s20180102.dao;

import java.util.List;

import oracle.java.s20180102.model.ReviewDto;

public interface ReviewDao {
	//List<ReviewDto> selReviewList(String ID, int GservNo); // 후기리스트 
	//int inReview(ReviewDto reviewDto);                     // 후기 등록
	//int upReview(ReviewDto reviewDto);                     // 후기 수정
	//int delReview(ReviewDto reviewDto);                    // 후기 삭제	
}